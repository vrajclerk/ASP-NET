using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using SessionDemo.Models;
using Microsoft.AspNetCore.Http;

namespace SessionDemo.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            HttpContext.Session.SetString("mykey", "myval");
            return View();
        }
        public IActionResult getsession()
        {
            if (HttpContext.Session.GetString("mykey") != null)
            {
                ViewBag.sess = HttpContext.Session.GetString("mykey");

            }
            return View();
        }
        public IActionResult wf2()
        {
            if (HttpContext.Session.GetString("mykey") != null)
            {
                ViewBag.sess = HttpContext.Session.GetString("mykey");

            }
            return View();
        }
        public IActionResult rmsess()
        {
            if (HttpContext.Session.GetString("mykey") != null)
            {
                 HttpContext.Session.Remove("mykey");

            }
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
