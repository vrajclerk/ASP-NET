using System.Diagnostics;
using CookiesDemo.Models;
using Microsoft.AspNetCore.Mvc;

namespace CookiesDemo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            if (Request.Cookies["nm"]!=null)
            {
                ViewBag.msg = Request.Cookies["nm"];
            }
            else
            {
                ViewBag.msg = "no cookies set";
            }
            return View();
        }
        [HttpPost]
        public IActionResult Index(IFormCollection fm)
        {
            CookieOptions co = new CookieOptions();
            co.Expires = DateTime.Now.AddMinutes(10);
            co.Secure = true;
            co.Path = "/";
            co.MaxAge = TimeSpan.FromDays(1);
            co.HttpOnly= true;
            Response.Cookies.Append("nm", fm["txtcookie"].ToString(), co);
            return RedirectToAction("Index");

           
        }
        [HttpPost]
        public IActionResult Delete()
        {
            if (Request.Cookies["nm"]!=null)
            {
                Response.Cookies.Delete("nm");
                ViewBag.msg = "Cookie deleted";
            }
            return View("Index");
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
