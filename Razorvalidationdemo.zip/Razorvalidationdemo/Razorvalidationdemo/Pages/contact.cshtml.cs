using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Razorvalidationdemo.Pages
{
    public class contactModel : PageModel
    {
        [BindProperty]
        [Required(ErrorMessage ="Name cannot be null")]
        [MinLength(3)]
        public string Name { get; set; } = "";
		[BindProperty]
        [Range(10,20,ErrorMessage ="Enter betw 10 to 20")]
       	public string Age { get; set; } = "";
        [BindProperty]
        [DataType(DataType.Date)]
        public DateTime DOB { get; set; }
		public void OnGet()
        {
        }
        public void OnPost()
        { }

    }
}
