using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Razorvalidationdemo.Pages
{
    public class FirstModel : PageModel
    {
        public string msg { get; set; }
        public void OnGet()
        {
            msg = "Hello all " + DateTime.Now.ToShortDateString();
        }
    }
}
