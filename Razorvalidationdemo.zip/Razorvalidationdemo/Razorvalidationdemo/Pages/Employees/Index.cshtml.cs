using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Razorvalidationdemo.Pages.Employees
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
