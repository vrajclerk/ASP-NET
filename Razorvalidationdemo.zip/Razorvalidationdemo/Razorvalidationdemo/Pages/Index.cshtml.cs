using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Razorvalidationdemo.Pages
{
	public class IndexModel : PageModel
	{
		[BindProperty]
		[Required(ErrorMessage ="Name cannot be null")]
		public string Name { get; set; } = "";
        [BindProperty]
		[Required(ErrorMessage ="Email is mandatory")]
		[RegularExpression("^[6-9]\\d{3}$")]
        public string Email { get; set; } = "";
		public string err = "";
		public string succ = "";
		public void OnGet()
		{

		}
		public void OnPost()
		{
			if(!ModelState.IsValid)
			{
				err = "fill the req details";
				return;
			}
			else {
				succ = "Data submitted";
				ModelState.Clear();
			}

		}
	}
}
